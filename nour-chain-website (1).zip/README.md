# Nour Chain — Telegram Mini App

Premium black/white futuristic mining Mini App. React + Vite + Firebase (Firestore + Hosting).

## 1. Configure

1. Open `src/firebase.ts` and paste your Firebase web config (Firebase Console → Project Settings → Web app).
2. Set `TELEGRAM_BOT_USERNAME` to your bot username (without `@`).
3. Edit `.firebaserc` and set your Firebase project ID.

## 2. Install & run

```bash
npm install
npm run dev
```

The app uses a dev fallback user so it loads in a browser. Inside Telegram it reads the real user via `window.Telegram.WebApp`.

## 3. Firestore collections

- `users` — created automatically on first visit (doc ID = Telegram user ID)
- `tasks` — managed in Admin
- `community_links` — managed in Admin
- `claims`, `referrals`, `rewards`, `settings` — runtime/admin data

## 4. Admin

Open `/admin` and enter password `543211`. Manage tasks, community links, and user balances.

> Password is client-side. For production replace with a Cloud Function + Firebase Auth custom claim.

## 5. Deploy to Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase deploy
```

Build runs automatically before deploy if you use `npm run deploy`. Firestore rules in `firestore.rules` are deployed alongside.

## 6. Telegram Mini App setup

1. In BotFather: `/newapp` → choose your bot → set the Web App URL to your Firebase Hosting URL (e.g. `https://your-project.web.app`).
2. Set the Menu Button to point to the same URL.
3. Referral links: `https://t.me/<bot>?start=<userId>` (handled automatically by the app).

## 7. Security notes

- `firestore.rules` restricts profile writes to safe fields. Balances *should* be mutated only by Cloud Functions in production — the current client write paths (claim / tasks) are open for the Mini App MVP. Move them to Cloud Functions for full anti-abuse protection (validate `initData` HMAC server-side, enforce 12h cooldown).
- Validate Telegram `initData` server-side using your bot token before granting rewards.

## 8. Folder structure

```
src/
  components/   # LoadingScreen, Layout, BottomNav, MiningCharacter
  contexts/     # AuthContext (Telegram + Firestore)
  pages/        # Home, Tasks, Community, Referral, Account, Game, Admin
  firebase.ts   # Firebase web config + bot username
  telegram.ts   # WebApp SDK helpers
firebase.json
firestore.rules
```
