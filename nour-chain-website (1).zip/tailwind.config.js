/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: { display: ["Orbitron", "system-ui", "sans-serif"], sans: ["Inter", "system-ui", "sans-serif"] },
      colors: { ink: "#0a0a0a", smoke: "#111113", ash: "#1a1a1d", silver: "#d6d6d8" },
      boxShadow: { glow: "0 0 40px rgba(255,255,255,0.25)", "glow-sm": "0 0 14px rgba(255,255,255,0.15)" },
      animation: {
        float: "float 6s ease-in-out infinite",
        pulseGlow: "pulseGlow 2.5s ease-in-out infinite",
        spinSlow: "spin 18s linear infinite",
        shimmer: "shimmer 2.5s linear infinite",
      },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-14px)" } },
        pulseGlow: {
          "0%,100%": { boxShadow: "0 0 0 0 rgba(255,255,255,0.5), 0 0 40px rgba(255,255,255,0.25)" },
          "50%": { boxShadow: "0 0 0 14px rgba(255,255,255,0), 0 0 60px rgba(255,255,255,0.45)" },
        },
        shimmer: { "0%": { backgroundPosition: "-200% 0" }, "100%": { backgroundPosition: "200% 0" } },
      },
    },
  },
  plugins: [],
};
