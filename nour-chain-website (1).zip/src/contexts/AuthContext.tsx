import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { doc, getDoc, setDoc, updateDoc, serverTimestamp, increment } from "firebase/firestore";
import { db } from "../firebase";
import { getTgUser, getStartParam, initTelegram, TgUser } from "../telegram";

export type UserDoc = {
  id: string;
  tgId: number;
  username?: string;
  firstName?: string;
  photoUrl?: string;
  nct: number;
  ton: number;
  usdt: number;
  binanceUid?: string;
  referralCode: string;
  referredBy?: string;
  lastClaim?: number;
  completedTasks?: string[];
  createdAt?: any;
  lastSeen?: any;
};

type Ctx = {
  tg: TgUser | null;
  user: UserDoc | null;
  loading: boolean;
  refresh: () => Promise<void>;
};

const AuthCtx = createContext<Ctx>({ tg: null, user: null, loading: true, refresh: async () => {} });
export const useAuth = () => useContext(AuthCtx);

function makeRefCode(id: number) {
  return "NC" + id.toString(36).toUpperCase().padStart(5, "0");
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [tg, setTg] = useState<TgUser | null>(null);
  const [user, setUser] = useState<UserDoc | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    initTelegram();
    const t = getTgUser();
    setTg(t);
    if (!t) { setLoading(false); return; }

    const uid = String(t.id);
    const ref = doc(db, "users", uid);
    const snap = await getDoc(ref);

    if (!snap.exists()) {
      const startParam = getStartParam();
      const data: UserDoc = {
        id: uid,
        tgId: t.id,
        username: t.username ?? "",
        firstName: t.first_name ?? "",
        photoUrl: t.photo_url ?? "",
        nct: 0,
        ton: 0,
        usdt: 0,
        referralCode: makeRefCode(t.id),
        referredBy: startParam || "",
        completedTasks: [],
        createdAt: serverTimestamp(),
        lastSeen: serverTimestamp(),
      };
      await setDoc(ref, data);

      // Reward referrer
      if (startParam && startParam !== uid) {
        try {
          const refRef = doc(db, "users", startParam);
          const refSnap = await getDoc(refRef);
          if (refSnap.exists()) {
            await updateDoc(refRef, { nct: increment(50) });
          }
        } catch {}
      }
      setUser(data);
    } else {
      const data = snap.data() as UserDoc;
      // Update lightweight profile fields
      await updateDoc(ref, {
        username: t.username ?? data.username ?? "",
        firstName: t.first_name ?? data.firstName ?? "",
        photoUrl: t.photo_url ?? data.photoUrl ?? "",
        lastSeen: serverTimestamp(),
      });
      setUser({ ...data, id: uid });
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  return (
    <AuthCtx.Provider value={{ tg, user, loading, refresh: load }}>
      {children}
    </AuthCtx.Provider>
  );
}
