import { useAuth } from "../contexts/AuthContext";
import { TELEGRAM_BOT_USERNAME, TELEGRAM_MINIAPP_NAME, db } from "../firebase";
import { isInsideTelegram } from "../telegram";
import { Copy, Share2, Users } from "lucide-react";
import { useState, useEffect } from "react";
import { collection, query, where, onSnapshot } from "firebase/firestore";

type ReferredUser = {
  id: string;
  firstName?: string;
  username?: string;
  photoUrl?: string;
  createdAt?: any;
};

export default function Referral() {
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);
  const [referred, setReferred] = useState<ReferredUser[]>([]);

  useEffect(() => {
    if (!user?.id) return;
    const q = query(collection(db, "users"), where("referredBy", "==", user.id));
    const unsub = onSnapshot(q, (snap) => {
      setReferred(
        snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }))
      );
    });
    return unsub;
  }, [user?.id]);

  if (!isInsideTelegram() && !import.meta.env.DEV) {
    return (
      <div className="glass-strong rounded-3xl p-8 text-center mt-10">
        <h1 className="font-display text-xl text-gradient mb-2">Open in Telegram</h1>
        <p className="text-white/60 text-sm">Please open this link in Telegram.</p>
      </div>
    );
  }

  const link = `https://t.me/${TELEGRAM_BOT_USERNAME}/${TELEGRAM_MINIAPP_NAME}?startapp=${user?.id ?? ""}`;
  const copy = async () => { await navigator.clipboard.writeText(link); setCopied(true); setTimeout(() => setCopied(false), 1500); };
  const share = () => {
    const tg = (window as any).Telegram?.WebApp;
    if (tg?.openTelegramLink) tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent("Join me on Nour Chain")}`);
    else window.open(`https://t.me/share/url?url=${encodeURIComponent(link)}`, "_blank");
  };

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl text-gradient">Referral</h1>
      <p className="text-white/50 text-sm">Invite friends — earn <span className="text-white">50 NCT</span> per signup.</p>

      <div className="glass rounded-2xl p-3 flex items-center gap-2">
        <p className="text-xs text-white/70 truncate flex-1">{link}</p>
        <button onClick={copy} className="px-3 py-2 rounded-xl bg-white/10 text-white text-xs flex items-center gap-1">
          <Copy size={14} /> {copied ? "Copied" : "Copy"}
        </button>
      </div>

      <button onClick={share} className="w-full btn-glow py-4 rounded-2xl font-display tracking-widest flex items-center justify-center gap-2">
        <Share2 size={18} /> SHARE WITH FRIENDS
      </button>

      <div className="grid grid-cols-2 gap-3 mt-2">
        <div className="glass rounded-2xl p-4 text-center">
          <p className="text-[10px] uppercase tracking-widest text-white/40">Per referral</p>
          <p className="font-display text-white text-lg mt-1">+50 NCT</p>
        </div>
        <div className="glass rounded-2xl p-4 text-center">
          <p className="text-[10px] uppercase tracking-widest text-white/40">Total referred</p>
          <p className="font-display text-white text-lg mt-1">{referred.length}</p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Users size={16} className="text-white/40" />
          <p className="text-[10px] uppercase tracking-widest text-white/40">Referred friends</p>
        </div>
        {referred.length === 0 && (
          <div className="glass rounded-2xl p-6 text-center">
            <p className="text-white/40 text-sm">No referrals yet. Share your link to get started!</p>
          </div>
        )}
        {referred.map((r) => (
          <div key={r.id} className="glass rounded-2xl p-3 flex items-center gap-3">
            {r.photoUrl ? (
              <img src={r.photoUrl} alt={r.firstName} className="w-10 h-10 rounded-full" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                <Users size={16} className="text-white/40" />
              </div>
            )}
            <div className="flex-1">
              <p className="text-white text-sm">{r.firstName || "Telegram User"}</p>
              {r.username && <p className="text-[10px] text-white/40">@{r.username}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
