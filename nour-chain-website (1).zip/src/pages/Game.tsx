import { Gamepad2 } from "lucide-react";

export default function Game() {
  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl text-gradient">My Games</h1>
      <p className="text-white/50 text-sm">Users will earn coins by playing games.</p>

      <div className="grid grid-cols-2 gap-3">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="glass-strong rounded-2xl p-4 h-40 flex flex-col items-center justify-center text-center">
            <Gamepad2 className="text-white/70 mb-2" />
            <p className="font-display text-white">Game {i}</p>
            <p className="text-[10px] uppercase tracking-widest text-white/40 mt-1">Coming soon</p>
          </div>
        ))}
      </div>
    </div>
  );
}
