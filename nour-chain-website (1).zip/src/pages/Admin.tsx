import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  collection, getDocs, addDoc, deleteDoc, doc, updateDoc, query, limit, orderBy,
} from "firebase/firestore";
import { db } from "../firebase";
import { ArrowLeft, Trash2 } from "lucide-react";

const ADMIN_PASSWORD = "543211";
const KEY = "nc_admin_ok";

type Task = { id: string; title: string; reward: number; link: string };
type CLink = { id: string; name: string; url: string; description?: string };

export default function Admin() {
  const [ok, setOk] = useState(() => sessionStorage.getItem(KEY) === "1");
  const [pwd, setPwd] = useState("");
  const [tab, setTab] = useState<"tasks" | "community" | "users">("tasks");

  if (!ok) {
    return (
      <div className="min-h-screen grid place-items-center p-6">
        <div className="glass-strong rounded-3xl p-6 w-full max-w-sm space-y-3">
          <h1 className="font-display text-xl text-gradient text-center">Admin Login</h1>
          <input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)}
                 placeholder="Password"
                 className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-3 text-white" />
          <button
            onClick={() => { if (pwd === ADMIN_PASSWORD) { sessionStorage.setItem(KEY, "1"); setOk(true); } }}
            className="w-full btn-glow py-3 rounded-xl">Enter</button>
          <Link to="/" className="block text-center text-xs text-white/40">Back to app</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen max-w-2xl mx-auto p-5 space-y-5">
      <header className="flex items-center justify-between">
        <Link to="/" className="text-white/60 flex items-center gap-1 text-sm"><ArrowLeft size={16} /> Back</Link>
        <h1 className="font-display text-xl text-gradient">Admin Dashboard</h1>
        <button onClick={() => { sessionStorage.removeItem(KEY); setOk(false); }} className="text-xs text-white/40">Logout</button>
      </header>

      <div className="glass rounded-2xl p-1 flex">
        {(["tasks", "community", "users"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-2 rounded-xl text-sm capitalize ${tab === t ? "bg-white text-black" : "text-white/60"}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === "tasks" && <TasksAdmin />}
      {tab === "community" && <CommunityAdmin />}
      {tab === "users" && <UsersAdmin />}
    </div>
  );
}

function TasksAdmin() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState(""); const [reward, setReward] = useState(10); const [link, setLink] = useState("");
  const load = async () => {
    const s = await getDocs(collection(db, "tasks"));
    setTasks(s.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
  };
  useEffect(() => { load(); }, []);
  const add = async () => {
    if (!title || !link) return;
    await addDoc(collection(db, "tasks"), { title, reward: Number(reward), link });
    setTitle(""); setLink(""); setReward(10); load();
  };
  const del = async (id: string) => { await deleteDoc(doc(db, "tasks", id)); load(); };

  return (
    <div className="space-y-3">
      <div className="glass-strong rounded-2xl p-4 space-y-2">
        <p className="text-xs uppercase tracking-widest text-white/40">Add task</p>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title"
               className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white text-sm" />
        <div className="flex gap-2">
          <input type="number" value={reward} onChange={(e) => setReward(+e.target.value)} placeholder="Reward"
                 className="w-28 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white text-sm" />
          <input value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://…"
                 className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white text-sm" />
        </div>
        <button onClick={add} className="btn-glow w-full py-2 rounded-xl text-sm">Add</button>
      </div>

      {tasks.map((t) => (
        <div key={t.id} className="glass rounded-2xl p-3 flex items-center gap-3">
          <div className="flex-1">
            <p className="text-white text-sm">{t.title}</p>
            <p className="text-[10px] text-white/40 truncate">{t.link} · +{t.reward} NCT</p>
          </div>
          <button onClick={() => del(t.id)} className="p-2 text-red-400"><Trash2 size={16} /></button>
        </div>
      ))}
    </div>
  );
}

function CommunityAdmin() {
  const [links, setLinks] = useState<CLink[]>([]);
  const [name, setName] = useState(""); const [url, setUrl] = useState(""); const [desc, setDesc] = useState("");
  const load = async () => {
    const s = await getDocs(collection(db, "community_links"));
    setLinks(s.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
  };
  useEffect(() => { load(); }, []);
  const add = async () => {
    if (!name || !url) return;
    await addDoc(collection(db, "community_links"), { name, url, description: desc });
    setName(""); setUrl(""); setDesc(""); load();
  };
  const del = async (id: string) => { await deleteDoc(doc(db, "community_links", id)); load(); };

  return (
    <div className="space-y-3">
      <div className="glass-strong rounded-2xl p-4 space-y-2">
        <p className="text-xs uppercase tracking-widest text-white/40">Add link</p>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name"
               className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white text-sm" />
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://t.me/…"
               className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white text-sm" />
        <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Description"
               className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white text-sm" />
        <button onClick={add} className="btn-glow w-full py-2 rounded-xl text-sm">Add</button>
      </div>

      {links.map((l) => (
        <div key={l.id} className="glass rounded-2xl p-3 flex items-center gap-3">
          <div className="flex-1">
            <p className="text-white text-sm">{l.name}</p>
            <p className="text-[10px] text-white/40 truncate">{l.url}</p>
          </div>
          <button onClick={() => del(l.id)} className="p-2 text-red-400"><Trash2 size={16} /></button>
        </div>
      ))}
    </div>
  );
}

function UsersAdmin() {
  const [users, setUsers] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      try {
        const s = await getDocs(query(collection(db, "users"), orderBy("createdAt", "desc"), limit(100)));
        setUsers(s.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
      } catch {
        const s = await getDocs(collection(db, "users"));
        setUsers(s.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
      }
    })();
  }, []);
  const updateBal = async (id: string, field: "nct" | "ton" | "usdt", value: number) => {
    await updateDoc(doc(db, "users", id), { [field]: value });
  };
  return (
    <div className="space-y-3">
      <p className="text-xs text-white/40">{users.length} users</p>
      {users.map((u) => (
        <div key={u.id} className="glass rounded-2xl p-3 space-y-2">
          <div className="flex items-center gap-3">
            {u.photoUrl ? <img src={u.photoUrl} className="w-10 h-10 rounded-full" /> :
              <div className="w-10 h-10 rounded-full bg-white/10" />}
            <div className="flex-1">
              <p className="text-white text-sm">{u.firstName} <span className="text-white/40">@{u.username}</span></p>
              <p className="text-[10px] text-white/40">ID: {u.tgId} · Ref: {u.referralCode}</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(["nct", "ton", "usdt"] as const).map((f) => (
              <label key={f} className="text-[10px] text-white/40">
                {f.toUpperCase()}
                <input type="number" defaultValue={u[f] ?? 0}
                       onBlur={(e) => updateBal(u.id, f, Number(e.target.value))}
                       className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-white text-xs mt-0.5" />
              </label>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
