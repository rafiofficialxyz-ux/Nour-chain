import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

export default function Account() {
  const { user, refresh } = useAuth();
  const [gmail, setGmail] = useState((user as any)?.gmail ?? "");
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [showConvert, setShowConvert] = useState(false);

  if (!user) return null;

  const save = async () => {
    setError("");
    const value = gmail.trim();
    if (!/^[^\s@]+@gmail\.com$/i.test(value)) {
      setError("Enter a valid Gmail address");
      return;
    }
    await updateDoc(doc(db, "users", user.id), { gmail: value });
    await refresh();
    setSaved(true); setTimeout(() => setSaved(false), 1500);
  };

  const canConvert = (user.nct ?? 0) >= 500;

  return (
    <div className="space-y-5">
      <div className="glass-strong rounded-3xl p-5 flex items-center gap-4">
        {user.photoUrl ? (
          <img src={user.photoUrl} className="w-16 h-16 rounded-full border border-white/20" />
        ) : (
          <div className="w-16 h-16 rounded-full bg-white/10 grid place-items-center font-display text-xl text-white">
            {(user.firstName ?? "U")[0]}
          </div>
        )}
        <div>
          <p className="font-display text-lg text-white">{user.firstName}</p>
          <p className="text-xs text-white/60">@{user.username || "—"}</p>
          <p className="text-[10px] text-white/40 mt-1">ID: {user.tgId}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { l: "NCT", v: user.nct?.toFixed(0) ?? "0" },
          { l: "TON", v: user.ton?.toFixed(2) ?? "0.00" },
          { l: "USDT", v: user.usdt?.toFixed(2) ?? "0.00" },
        ].map((c) => (
          <div key={c.l} className="glass rounded-2xl p-3 text-center">
            <p className="text-[10px] uppercase tracking-widest text-white/40">{c.l}</p>
            <p className="font-display text-white mt-1">{c.v}</p>
          </div>
        ))}
      </div>

      <div className="glass rounded-2xl p-4 space-y-2">
        <p className="text-xs uppercase tracking-widest text-white/40">Gmail Account</p>
        <div className="flex gap-2">
          <input value={gmail} onChange={(e) => setGmail(e.target.value)}
                 type="email"
                 placeholder="yourname@gmail.com"
                 className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white placeholder-white/30 text-sm" />
          <button onClick={save} className="btn-glow px-4 rounded-xl text-sm">{saved ? "Saved" : "Connect"}</button>
        </div>
        {error && <p className="text-xs text-red-400">{error}</p>}
      </div>

      <div className="grid grid-cols-3 gap-3">
        <button disabled className="glass rounded-2xl p-4 text-white/40 text-sm">Deposit<br /><span className="text-[10px]">Coming soon</span></button>
        <button disabled className="glass rounded-2xl p-4 text-white/40 text-sm">Withdraw<br /><span className="text-[10px]">Coming soon</span></button>
        <button disabled className="glass rounded-2xl p-4 text-white/40 text-sm">Convert<br /><span className="text-[10px]">Coming soon</span></button>
      </div>

      {showConvert && (
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-6 z-[100]" onClick={() => setShowConvert(false)}>
          <div className="glass-strong rounded-3xl p-6 max-w-xs text-center" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-lg text-white mb-2">Conversion</h3>
            <p className="text-white/60 text-sm">Conversion system coming soon.</p>
            <button onClick={() => setShowConvert(false)} className="mt-4 btn-glow px-5 py-2 rounded-xl text-sm">OK</button>
          </div>
        </div>
      )}
    </div>
  );
}
