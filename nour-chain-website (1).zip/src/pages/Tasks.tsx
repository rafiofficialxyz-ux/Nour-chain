import { useEffect, useState } from "react";
import { collection, getDocs, doc, updateDoc, increment, arrayUnion } from "firebase/firestore";
import { db } from "../firebase";
import { useAuth } from "../contexts/AuthContext";
import { ExternalLink, Check } from "lucide-react";

type Task = { id: string; title: string; reward: number; link: string };

export default function Tasks() {
  const { user, refresh } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [opened, setOpened] = useState<Record<string, boolean>>({});

  useEffect(() => {
    (async () => {
      const snap = await getDocs(collection(db, "tasks"));
      setTasks(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
    })();
  }, []);

  const claim = async (t: Task) => {
    if (!user) return;
    if (user.completedTasks?.includes(t.id)) return;
    if (!opened[t.id]) {
      const url = /^https?:\/\//i.test(t.link) ? t.link : `https://${t.link}`;
      const tg = (window as any).Telegram?.WebApp;
      if (tg?.openLink) tg.openLink(url); else window.open(url, "_blank");
      setOpened((o) => ({ ...o, [t.id]: true }));
      return;
    }
    await updateDoc(doc(db, "users", user.id), {
      nct: increment(t.reward),
      completedTasks: arrayUnion(t.id),
    });
    await refresh();
  };

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl text-gradient">Tasks</h1>
      <p className="text-white/50 text-sm">Complete tasks to earn NCT.</p>

      {tasks.length === 0 && (
        <div className="glass rounded-2xl p-6 text-center text-white/50 text-sm">
          No tasks yet. Admin can add tasks from the dashboard.
        </div>
      )}

      <div className="space-y-3">
        {tasks.map((t) => {
          const done = user?.completedTasks?.includes(t.id);
          return (
            <div key={t.id} className="glass-strong rounded-2xl p-4 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/10 grid place-items-center">
                {done ? <Check className="text-green-400" /> : <ExternalLink className="text-white" />}
              </div>
              <div className="flex-1">
                <p className="font-medium text-white">{t.title}</p>
                <p className="text-xs text-white/50">+{t.reward} NCT</p>
              </div>
              <button
                onClick={() => claim(t)}
                disabled={done}
                className={`px-4 py-2 rounded-xl text-sm font-semibold ${
                  done ? "bg-white/10 text-white/40" : opened[t.id] ? "btn-glow" : "bg-white/10 text-white"
                }`}
              >
                {done ? "Done" : opened[t.id] ? "Claim" : "Open"}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
