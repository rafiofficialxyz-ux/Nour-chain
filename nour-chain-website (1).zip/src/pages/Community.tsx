import { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";
import { Users } from "lucide-react";

type Link = { id: string; name: string; url: string; description?: string };

export default function Community() {
  const [links, setLinks] = useState<Link[]>([]);
  useEffect(() => {
    (async () => {
      const snap = await getDocs(collection(db, "community_links"));
      setLinks(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
    })();
  }, []);

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl text-gradient">Community</h1>
      <p className="text-white/50 text-sm">Join Nour Chain across the network.</p>

      {links.length === 0 && (
        <div className="glass rounded-2xl p-6 text-center text-white/50 text-sm">Coming soon.</div>
      )}

      <div className="grid grid-cols-1 gap-3">
        {links.map((l) => {
          const url = /^https?:\/\//i.test(l.url) ? l.url : `https://${l.url}`;
          const open = (e: React.MouseEvent) => {
            e.preventDefault();
            const tg = (window as any).Telegram?.WebApp;
            if (tg?.openLink) tg.openLink(url); else window.open(url, "_blank");
          };
          return (
            <a key={l.id} href={url} onClick={open}
               className="glass-strong rounded-2xl p-4 flex items-center gap-3 hover:bg-white/5 transition">
              <div className="w-12 h-12 rounded-xl bg-white/10 grid place-items-center"><Users className="text-white" /></div>
              <div className="flex-1">
                <p className="font-medium text-white">{l.name}</p>
                {l.description && <p className="text-xs text-white/50">{l.description}</p>}
              </div>
              <span className="text-xs text-white/60">Open</span>
            </a>
          );
        })}
      </div>
    </div>
  );
}
