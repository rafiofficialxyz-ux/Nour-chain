import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { doc, updateDoc, increment, addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";
import { useAuth } from "../contexts/AuthContext";
import MiningCharacter from "../components/MiningCharacter";

const CLAIM_INTERVAL = 12 * 60 * 60 * 1000;
const NCT_REWARD = 12;
const TON_REWARD = 0.06;

function fmt(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600).toString().padStart(2, "0");
  const m = Math.floor((s % 3600) / 60).toString().padStart(2, "0");
  const sec = (s % 60).toString().padStart(2, "0");
  return `${h}:${m}:${sec}`;
}

export default function Home() {
  const { user, refresh } = useAuth();
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);

  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);

  const nextClaim = (user?.lastClaim ?? 0) + CLAIM_INTERVAL;
  const ready = now >= nextClaim;
  const remaining = useMemo(() => Math.max(0, nextClaim - now), [nextClaim, now]);

  const claim = async () => {
    if (!user || !ready || busy) return;
    setBusy(true);
    try {
      const ref = doc(db, "users", user.id);
      await updateDoc(ref, {
        nct: increment(NCT_REWARD),
        ton: increment(TON_REWARD),
        lastClaim: Date.now(),
      });
      await addDoc(collection(db, "claims"), {
        userId: user.id, nct: NCT_REWARD, ton: TON_REWARD, at: serverTimestamp(),
      });
      await refresh();
    } finally { setBusy(false); }
  };

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-white/40">Welcome</p>
          <h1 className="font-display text-2xl text-gradient">{user?.firstName || "Miner"}</h1>
        </div>
        <div className="glass rounded-2xl px-3 py-2 text-right">
          <p className="text-[10px] uppercase tracking-widest text-white/40">Balance</p>
          <p className="font-display text-white">{user?.nct?.toFixed(0) ?? 0} <span className="text-white/50 text-xs">NCT</span></p>
        </div>
      </header>

      <div className="glass-strong rounded-3xl p-4 relative overflow-hidden particles">
        <MiningCharacter />
        <div className="grid grid-cols-2 gap-3 mt-2">
          <div className="glass rounded-2xl p-3">
            <p className="text-[10px] uppercase tracking-widest text-white/40">NCT</p>
            <p className="font-display text-lg text-white">+{NCT_REWARD}</p>
          </div>
          <div className="glass rounded-2xl p-3">
            <p className="text-[10px] uppercase tracking-widest text-white/40">TON</p>
            <p className="font-display text-lg text-white">+{TON_REWARD}</p>
          </div>
        </div>

        <div className="mt-4">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={claim}
            disabled={!ready || busy}
            className={`w-full py-4 rounded-2xl font-display tracking-widest ${
              ready ? "btn-glow animate-pulseGlow" : "glass text-white/50"
            }`}
          >
            {busy ? "CLAIMING…" : ready ? "CLAIM REWARD" : `NEXT IN ${fmt(remaining)}`}
          </motion.button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[
          { l: "NCT", v: user?.nct?.toFixed(0) ?? "0" },
          { l: "TON", v: user?.ton?.toFixed(2) ?? "0.00" },
        ].map((c) => (
          <div key={c.l} className="glass rounded-2xl p-3 text-center">
            <p className="text-[10px] uppercase tracking-widest text-white/40">{c.l}</p>
            <p className="font-display text-white mt-1">{c.v}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
