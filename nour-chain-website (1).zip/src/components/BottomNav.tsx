import { NavLink } from "react-router-dom";
import { Home, ListChecks, Users, Gift, User, Gamepad2 } from "lucide-react";

const items = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/tasks", icon: ListChecks, label: "Tasks" },
  { to: "/community", icon: Users, label: "Community" },
  { to: "/referral", icon: Gift, label: "Referral" },
  { to: "/account", icon: User, label: "Account" },
  { to: "/game", icon: Gamepad2, label: "Game" },
];

export default function BottomNav() {
  return (
    <nav className="fixed bottom-3 left-1/2 -translate-x-1/2 w-[96%] max-w-md z-50">
      <div className="glass-strong rounded-2xl px-2 py-2 flex justify-between">
        {items.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              `flex-1 flex flex-col items-center gap-1 py-2 rounded-xl text-[10px] transition ${
                isActive ? "bg-white text-black shadow-glow-sm" : "text-white/60 hover:text-white"
              }`
            }
          >
            <Icon size={18} />
            <span className="font-medium tracking-wide">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
