import { Canvas, useFrame, useLoader } from "@react-three/fiber";
import { Float, Environment } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import logoUrl from "@/assets/coin-logo.png";

function Coin() {
  const ref = useRef<THREE.Group>(null);
  const logo = useLoader(THREE.TextureLoader, logoUrl);

  // Build a face texture: silver background with the logo centered.
  const faceTexture = useMemo(() => {
    const size = 512;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d")!;
    // radial silver gradient
    const grad = ctx.createRadialGradient(size / 2, size / 2, 20, size / 2, size / 2, size / 2);
    grad.addColorStop(0, "#ffffff");
    grad.addColorStop(0.6, "#d8d8dc");
    grad.addColorStop(1, "#7a7a7e");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
    ctx.fill();

    // outer ring
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 2 - 18, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = "#bdbdc2";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 2 - 36, 0, Math.PI * 2);
    ctx.stroke();

    // draw logo to match uploaded look: white center mark on a black disc
    const img = logo.image as HTMLImageElement;
    if (img) {
      const pad = size * 0.14;
      const innerSize = size - pad * 2;
      const cx = size / 2;
      const cy = size / 2;
      // black disc behind the logo
      ctx.fillStyle = "#0a0a0a";
      ctx.beginPath();
      ctx.arc(cx, cy, innerSize / 2, 0, Math.PI * 2);
      ctx.fill();
      // subtle inner ring
      ctx.strokeStyle = "#2a2a2a";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, innerSize / 2 - 6, 0, Math.PI * 2);
      ctx.stroke();

      // prepare logo: keep white where it was white, transparent elsewhere
      const off = document.createElement("canvas");
      off.width = img.width;
      off.height = img.height;
      const octx = off.getContext("2d")!;
      octx.drawImage(img, 0, 0);
      const data = octx.getImageData(0, 0, img.width, img.height);
      for (let i = 0; i < data.data.length; i += 4) {
        const r = data.data[i];
        const g = data.data[i + 1];
        const b = data.data[i + 2];
        const lum = (r + g + b) / 3;
        // white pixels -> opaque white; dark pixels -> transparent
        data.data[i] = 255;
        data.data[i + 1] = 255;
        data.data[i + 2] = 255;
        data.data[i + 3] = lum;
      }
      octx.putImageData(data, 0, 0);
      const lp = size * 0.22;
      ctx.drawImage(off, lp, lp, size - lp * 2, size - lp * 2);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.anisotropy = 8;
    tex.needsUpdate = true;
    return tex;
  }, [logo]);

  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.y += delta * 1.4;
  });

  return (
    <group ref={ref}>
      {/* Coin edge (cylinder side) */}
      <mesh rotation={[Math.PI / 2, 0, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[1.2, 1.2, 0.16, 96, 1, true]} />
        <meshStandardMaterial
          color="#cfcfd4"
          metalness={1}
          roughness={0.25}
          side={THREE.DoubleSide}
        />
      </mesh>
      {/* Front face */}
      <mesh position={[0, 0, 0.0801]}>
        <circleGeometry args={[1.2, 96]} />
        <meshStandardMaterial
          map={faceTexture}
          metalness={0.9}
          roughness={0.22}
        />
      </mesh>
      {/* Back face */}
      <mesh position={[0, 0, -0.0801]} rotation={[0, Math.PI, 0]}>
        <circleGeometry args={[1.2, 96]} />
        <meshStandardMaterial
          map={faceTexture}
          metalness={0.9}
          roughness={0.22}
        />
      </mesh>
    </group>
  );
}

export default function MiningCharacter() {
  return (
    <div className="relative h-64 grid place-items-center">
      <div className="absolute w-72 h-72 rounded-full bg-white/10 blur-3xl" />
      <Canvas
        className="relative"
        camera={{ position: [0, 0, 4], fov: 45 }}
        dpr={[1, 2]}
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[4, 4, 5]} intensity={2.2} />
        <directionalLight position={[-4, -2, -3]} intensity={0.9} color="#9aa0a6" />
        <Float speed={2} rotationIntensity={0.25} floatIntensity={0.7}>
          <Coin />
        </Float>
        <Environment preset="studio" />
      </Canvas>
    </div>
  );
}
