import { motion } from "framer-motion";

export default function LoadingScreen() {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden particles">
      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="relative"
      >
        <div className="absolute inset-0 rounded-full blur-3xl bg-white/20 animate-pulseGlow" />
        <div className="relative w-40 h-40 rounded-full glass-strong grid place-items-center animate-spinSlow">
          <div className="w-28 h-28 rounded-full border border-white/30 grid place-items-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-b from-white to-zinc-400 shadow-glow" />
          </div>
        </div>
      </motion.div>
      <motion.h1
        initial={{ y: 16, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-8 font-display text-3xl tracking-widest text-gradient"
      >
        NOUR CHAIN
      </motion.h1>
      <p className="mt-2 text-xs uppercase tracking-[0.4em] text-white/40">Initializing core</p>
    </div>
  );
}
