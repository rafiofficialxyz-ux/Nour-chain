import { Outlet } from "react-router-dom";
import BottomNav from "./BottomNav";

export default function Layout() {
  return (
    <div className="relative min-h-screen pb-28">
      <main className="max-w-md mx-auto px-4 pt-6">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
}
